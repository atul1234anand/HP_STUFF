import java.lang.Thread;

public class TRunnable implements Runnable {
	public void run() {
		System.out.println(Thread.currentThread().getName());
	}
	public static void main(String[] args) throws InterruptedException {
		Thread myThread = new Thread(new TRunnable(), "TRunnable");
		myThread.start();
	}
}
