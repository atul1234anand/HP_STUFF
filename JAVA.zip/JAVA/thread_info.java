
import java.lang.Thread;

public class thread_info{
    public static void main (String[] args){
        System.out.println("id="+ Thread.currentThread().getId());
        System.out.println("name="+ Thread.currentThread().getName());
        System.out.println("state="+ Thread.currentThread().getState());
        System.out.println("priority="+ Thread.currentThread().getPriority());
        System.out.println("threadgroupname="+Thread.currentThread().getThreadGroup().getName());
    }
}
