import java.lang.Thread;

public class runThread extends Thread {
	public runThread(String name) {
		super(name);
	}
	@Override
	public void run(){
		System.out.println("Executing thread "+Thread.currentThread().getName());
	}
	public static void main(String[] args) throws InterruptedException{
		runThread Thread1 = new runThread("Thread");
		Thread1.start();
	}
}
