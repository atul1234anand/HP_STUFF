import java.lang.Thread;
public class IRunnable implements Runnable {
    public void run(){
        try{
            Thread.sleep(17000);
        }catch (InterruptedException e){
            System.out.println(Thread.currentThread().getId()+" Interrupted");
        }
        while (!Thread.interrupted()){
            //do nothing
	    System.out.println("OK!")
        }
        System.out.println(Thread.currentThread().getId()+" woken");
    }
    public static void main(String[] args) throws InterruptedException{
        Thread t1 = new Thread(new IRunnable(),"LOL");
        t1.start();
        Thread.sleep(1000);
        t1.interrupt();
    }
}
