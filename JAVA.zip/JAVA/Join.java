import java.lang.Thread;

public class Join implements Runnable {
	private Random rand = new Random(System.currentTimeMillis());
	public void run() {
		for(int i=0; i<1000; i++) {
			rand.nextInt();
		}
		System.out.println(Thread.currentThread().getName()+ "done");
	}
	public static void main(String[] args) throws InterruptedException {
		Thread[] threads = new Thread[5];
		for(int i=0; i<threads.length; i++) {
			threads[i] = new Thread(new Join(),"LOL"+i);
			threads[i].start();
		}
		for(int i=0; i<threads.length; i++) {
			threads[i].join();
		}
	}
}
