import threading
import time
def func_1(name,delay):
    count = 0
    while count < 5:
        time.sleep(delay)
        count += 1
        print(name,delay)

t1 = threading.Thread(None,func_1,"Thread1",("Thread1",1))
t2 = threading.Thread(None,func_1,"Thread2",("Thread2",2))
t1.start()
t2.start()
