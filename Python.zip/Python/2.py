import threading

balance_1 = 1000
lock = threading.Lock()

def update(change):
    lock.acquire()
    global balance
    if (balance_1 + change < 1000):
        print("low balance")
    else:
        balance = balance + change
        print("After",balance) 
    lock.release()

threads = []
for i in range(1,21):
    if (i %2==0):
        threads.append(threading.Thread(None,update,i,(-100,)))
    else:
        threads.append(threading.Thread(None,update,i,(100,)))
    
for j in threads:
    j.start()


