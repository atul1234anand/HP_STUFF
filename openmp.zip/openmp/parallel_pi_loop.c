#include <stdio.h>
#include <omp.h>
int main(){
    double sum = 0.0; 
    #pragma omp parallel for reduction(+:sum) schedule(runtime)
    for (long count =0; count < 10000; count += 1){
            double x = (double)(count)*(1.0/10000);
            sum += 4.0/(1.0+x*x);
            
    }
    printf("value of PI is %lf\n",sum*(1.0/10000));
}
