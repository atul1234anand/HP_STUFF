#include <stdio.h>
#include <omp.h>

int main(){
	omp_set_num_threads(4);
	double step = 1.0/10000;
	int n = omp_get_num_threads();
	pi = 0.0
	#pragma omp parallel
	{
		int sum = 0;
		double x = 0;
		int id = omp_get_thread_num();
		for(int i = id;i<10000;i+=n){
			x = (double)(i)*step;
            		sum += 4.0/(1.0+x*x);
		}
		#pragma omp critical
		pi += sum*step;
	}
}
